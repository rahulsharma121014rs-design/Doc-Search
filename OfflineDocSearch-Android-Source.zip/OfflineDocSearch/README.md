# Offline Document Search (Android)

Fully offline runtime search app for Word and Excel files.

## Supported formats
- Word: `.doc`, `.docx`
- Excel: `.xls`, `.xlsx`

## Features
- Android Storage Access Framework folder selection
- Recursive folder scanning
- Local SQLite FTS4 full-text index
- Exact phrase / prefix-style search
- Hindi and English Unicode text
- Excel sheet names and cell contents indexed
- Word paragraphs and table text indexed
- Tap result to open the original document in an installed app
- No server, account, or network is required at runtime

## Build
Open this folder in Android Studio with JDK 17 and let Gradle resolve dependencies, then Build > Build APK(s).

The Apache POI dependencies are compile-time libraries; the app performs parsing locally on-device and does not upload documents.
