package com.ar.offlinedocsearch;

import android.content.*;import android.net.Uri;import android.provider.DocumentsContract;import java.io.*;import java.util.*;import org.apache.poi.hwpf.HWPFDocument;import org.apache.poi.hwpf.extractor.WordExtractor;import org.apache.poi.hssf.usermodel.HSSFWorkbook;import org.apache.poi.xssf.usermodel.XSSFWorkbook;import org.apache.poi.xwpf.usermodel.*;import org.apache.poi.ss.usermodel.*;

public class DocumentParser {
 static String ext(String n){int i=n.lastIndexOf('.');return i<0?"":n.substring(i+1).toLowerCase(Locale.ROOT);}
 public static boolean supported(String n){String e=ext(n);return e.equals("doc")||e.equals("docx")||e.equals("xls")||e.equals("xlsx");}
 public static String parse(Context c,Uri u,String name)throws Exception{
  try(InputStream in=c.getContentResolver().openInputStream(u)){String e=ext(name);
   if(e.equals("docx")){XWPFDocument d=new XWPFDocument(in);StringBuilder s=new StringBuilder();for(XWPFParagraph p:d.getParagraphs())s.append(p.getText()).append('\n');for(XWPFTable t:d.getTables())for(XWPFTableRow r:t.getRows())for(XWPFTableCell cell:r.getTableCells())s.append(cell.getText()).append('\t');d.close();return s.toString();}
   if(e.equals("doc")){HWPFDocument d=new HWPFDocument(in);return new WordExtractor(d).getText();}
   Workbook w=e.equals("xls")?new HSSFWorkbook(in):new XSSFWorkbook(in);StringBuilder s=new StringBuilder();for(Sheet sh:w){s.append("\n[SHEET: ").append(sh.getSheetName()).append("]\n");for(Row r:sh)for(Cell cell:r){s.append(cell.toString()).append('\t');}s.append('\n');}w.close();return s.toString();
  }
 }
 public static List<Uri> children(Context c,Uri tree){ArrayList<Uri> out=new ArrayList<>();Uri q=DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));Cursor cur=c.getContentResolver().query(q,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null);if(cur==null)return out;try{while(cur.moveToNext()){String id=cur.getString(0),mime=cur.getString(1),name=cur.getString(2);Uri u=DocumentsContract.buildDocumentUriUsingTree(tree,id);if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime))out.addAll(children(c,u));else if(supported(name))out.add(u);}}finally{cur.close();}return out;}
}
