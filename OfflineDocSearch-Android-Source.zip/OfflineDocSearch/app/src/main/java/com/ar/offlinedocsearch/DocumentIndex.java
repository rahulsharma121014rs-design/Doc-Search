package com.ar.offlinedocsearch;

import android.content.*;import android.database.*;import android.database.sqlite.*;import java.util.*;

public class DocumentIndex extends SQLiteOpenHelper {
  public static final String DB="documents.db"; public DocumentIndex(Context c){super(c,DB,null,1);}
  public void onCreate(SQLiteDatabase db){db.execSQL("CREATE VIRTUAL TABLE docs USING fts4(name,path,kind,content)");}
  public void onUpgrade(SQLiteDatabase db,int o,int n){}
  public void clear(){getWritableDatabase().execSQL("DELETE FROM docs");}
  public void add(String name,String path,String kind,String content){ContentValues v=new ContentValues();v.put("name",name);v.put("path",path);v.put("kind",kind);v.put("content",content);getWritableDatabase().insert("docs",null,v);}
  public Cursor search(String q){String safe=q.replace("\"","\"\""); return getReadableDatabase().rawQuery("SELECT name,path,kind,snippet(docs,3,'[',']',' … ',24) FROM docs WHERE docs MATCH ? LIMIT 200",new String[]{"\""+safe+"\" OR "+safe+"*"});}
}
